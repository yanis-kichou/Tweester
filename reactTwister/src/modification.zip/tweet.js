import React, { Component } from 'react';
import Emogi from "./Emogi";
export default class tweet extends Component{
    constructor(props){
        super(props);
    
        this.state={
            listEmogi:['😀','😬','😂','😍'],
            c:true
        }
        this.emogi=this.emogi.bind(this);
    }
    emogi(e){
                document.getElementById("tweet").value=document.getElementById("tweet").value+e}
    render(){
        return(
            <div class="t">
                <input type="text" placeholder="Write a tweet" id="tweet" ref="tweet"/>
                <button onClick={(event)=>this.props.addTweet(this.refs.tweet.value)}>share</button>
                
              <Emogi listEmogi={this.state.listEmogi} emogi={this.emogi}></Emogi>
            </div>
        )
    }
}